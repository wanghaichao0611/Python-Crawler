from extern.ldm_zero123.modules.image_degradation.bsrgan import (
    degradation_bsrgan_variant as degradation_fn_bsr,
)
from extern.ldm_zero123.modules.image_degradation.bsrgan_light import (
    degradation_bsrgan_variant as degradation_fn_bsr_light,
)
