# wget https://huggingface.co/cvlab/zero123-weights/resolve/main/105000.ckpt
# mv 105000.ckpt zero123-original.ckpt
wget https://zero123.cs.columbia.edu/assets/zero123-xl.ckpt
# Download stable_zero123.ckpt from https://huggingface.co/stabilityai/stable-zero123
