# Shape Credits

- `animal.obj` - Ido Richardson
- `hand_prismatic.obj` - Ido Richardson
- `potion.obj` - Ido Richardson
- `blub.obj` - [Keenan's 3D Model Repository](https://www.cs.cmu.edu/~kmcrane/Projects/ModelRepository/)
- `nascar.obj` - [Princeton ModelNet](https://modelnet.cs.princeton.edu/)
- `cabin.obj` - [Princeton ModelNet](https://modelnet.cs.princeton.edu/)
- `teddy.obj` - [Gal Metzer](https://galmetzer.github.io/)
- `human.obj` - [TurboSquid](https://www.turbosquid.com/3d-models/3d-model-character-base/524860)
